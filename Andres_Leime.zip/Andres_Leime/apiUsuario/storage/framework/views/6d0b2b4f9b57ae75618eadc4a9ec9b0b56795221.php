
<?php $__env->startSection('title','HOLA '.$id); ?>
<?php $__env->startSection('content'); ?>
<h1> HOLA <?php echo $id;?> AQUIiiii MOSTRAREMOS LO USUARIOS </h1>
<?php $__env->stopSection(); ?> 


<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\apiUsuario\resources\views/Rutas/show.blade.php ENDPATH**/ ?>