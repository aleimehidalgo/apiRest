

<?php $__env->startSection('title','PAGINA INICIAL'); ?>
<?php $__env->startSection('content'); ?>
<h1> ESTA ES UNA BIENVENIDA LOS USUARIOS SON =)</h1>

<?php $__env->stopSection(); ?> 

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\apiUsuario\resources\views/Rutas/index.blade.php ENDPATH**/ ?>