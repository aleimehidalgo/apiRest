
<?php $__env->startSection('title','CREAR NUEVOS USUARIOS'); ?>
<?php $__env->startSection('content'); ?>
<h1> AQUI MOSTRAREMOS LO NUEVOS USUARIOS </h1>

   <ul>
    <?php $__currentLoopData = $usuario; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($user->name); ?> su email es <?php echo e($user->email); ?></li>    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </ul>
   <?php echo e($usuario->links()); ?>

   <a href=<?php echo e(route('privada')); ?>>PAGINA FINAL =(</a>
<?php $__env->stopSection(); ?> 


<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\apiUsuario\resources\views/Rutas/create.blade.php ENDPATH**/ ?>