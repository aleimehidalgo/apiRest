@extends('layouts.plantilla')
@section('title','CREAR NUEVOS USUARIOS')
@section ('content')
<h1> AQUI MOSTRAREMOS LO NUEVOS USUARIOS </h1>

   <ul>
    @foreach ($usuario as $user)
    <li>{{$user->name}} su email es {{$user->email}}</li>    
    @endforeach
   </ul>
   {{$usuario->links()}}
   <a href={{ route('privada') }}>PAGINA FINAL =(</a>
@endsection 

