
@extends('layouts.plantilla')
@section('title','PAGINA INICIAL')
@section ('content')
<h1> ESTA ES UNA BIENVENIDA LOS USUARIOS SON =)</h1>

@endsection 
