@extends('layouts.plantilla')
@section('title','HOLA '.$id)
@section ('content')
<h1> HOLA <?php echo $id;?> AQUIiiii MOSTRAREMOS LO USUARIOS </h1>
@endsection 

