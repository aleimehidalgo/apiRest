<?php

namespace App\Http\Controllers;

use App\Models\users;
use Illuminate\Http\Request;

class RutaController extends Controller
{
    public function index(){
        
        return view('Rutas.index');
    }
    public function create(){
        $usuario=users::paginate(1);
        // return $usuario;
        return view('Rutas.create',compact('usuario'));
    }
    public function show($id){
        return view('Rutas.show',['id'=>$id]);
    }
}
