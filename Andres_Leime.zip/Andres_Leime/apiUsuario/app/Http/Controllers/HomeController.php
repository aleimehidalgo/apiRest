<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
  public function __invoke(){
  //  return "ESTAS SIENDO LLAMADO DESDE EL CONTROLADOR";
  return view('Rutas.index');
  }
}
