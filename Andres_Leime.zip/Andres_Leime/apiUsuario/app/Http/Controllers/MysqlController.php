<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\users;
use \DB;
class MysqlController extends Controller
{
    public function obtenenTodosUsuarios(){
        return  users ::all();
    }
}
