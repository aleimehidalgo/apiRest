-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 15-01-2023 a las 05:01:22
-- Versión del servidor: 8.0.30
-- Versión de PHP: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `tienda`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `category`
--

CREATE TABLE `category` (
  `id_category` bigint NOT NULL,
  `name_category` varchar(255) COLLATE utf8mb4_spanish_ci NOT NULL,
  `observation_category` text COLLATE utf8mb4_spanish_ci NOT NULL,
  `created_at_category` timestamp NOT NULL,
  `updated_at_category` timestamp NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `category`
--

INSERT INTO `category` (`id_category`, `name_category`, `observation_category`, `created_at_category`, `updated_at_category`) VALUES
(1, 'VESTIMENTA', 'AREA TEXTIL', '2023-01-14 17:03:46', '2023-01-14 17:03:46'),
(2, 'TECNOLOGIA', 'DEPARTAMENTO DE INFORMACION', '2023-01-14 17:04:13', '2023-01-14 17:04:13');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `category_product`
--

CREATE TABLE `category_product` (
  `category_id` bigint NOT NULL,
  `product_id` bigint NOT NULL,
  `promotion` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `category_product`
--

INSERT INTO `category_product` (`category_id`, `product_id`, `promotion`) VALUES
(2, 3, 1),
(2, 4, 0),
(1, 6, 0),
(1, 5, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `products`
--

CREATE TABLE `products` (
  `id_product` bigint NOT NULL,
  `name_product` varchar(255) COLLATE utf8mb4_spanish_ci NOT NULL,
  `price_product` decimal(10,0) NOT NULL,
  `photo_prduct` varchar(255) COLLATE utf8mb4_spanish_ci NOT NULL,
  `observation_product` text COLLATE utf8mb4_spanish_ci NOT NULL,
  `size_product` enum('S','M','L','XL') COLLATE utf8mb4_spanish_ci NOT NULL,
  `created_at_product` timestamp NOT NULL,
  `update_at_product` timestamp NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `products`
--

INSERT INTO `products` (`id_product`, `name_product`, `price_product`, `photo_prduct`, `observation_product`, `size_product`, `created_at_product`, `update_at_product`) VALUES
(3, 'computora', '300', '', 'computadora de escritorio', 'M', '2023-01-14 17:01:24', '2023-01-14 17:01:24'),
(4, 'Pantalla', '100', '', 'monitor de escritorio', 'M', '2023-01-14 17:01:24', '2023-01-14 17:01:24'),
(5, 'chompa', '50', '', 'chompa de cuero', 'L', '2023-01-14 17:02:52', '2023-01-14 17:02:52'),
(6, 'camiseta', '10', '', 'camiseta llana color azul', 'L', '2023-01-14 17:02:52', '2023-01-14 17:02:52');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` bigint NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_spanish_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_spanish_ci NOT NULL,
  `email_verified_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `password` varchar(255) COLLATE utf8mb4_spanish_ci NOT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Andres Leime', 'aleimehidalgo@gmail.com', '2023-01-13 11:30:11', 'andres123', '', '2023-01-13 11:30:11', '2023-01-13 11:30:11'),
(2, 'Soledad Rios', 'soledadmacas@gmail.com', '2023-01-14 17:12:55', 'admin123', '', '2023-01-14 17:12:55', '2023-01-14 17:12:55'),
(3, 'David Enrique Leime Hidalgo', 'davidleime@gmail.com', '2023-01-14 17:12:55', 'admin123', '', '2023-01-14 17:12:55', '2023-01-14 17:12:55'),
(4, 'Maria De Lourdes', 'malourdes@gmail.com', '2023-01-14 23:59:09', 'lourdes1234', NULL, '2023-01-15 04:47:22', '2023-01-15 04:47:22'),
(5, 'juan', 'juan@gmail.com', '2023-01-15 03:44:02', '$2y$10$XhgKL8nyCLUAtHIKqK5/a.dBEBTszn/L7IU6vH0ZxiShJ2gD4FM/O', NULL, '2023-01-15 08:44:02', '2023-01-15 08:44:02'),
(6, 'juanca', 'juan@gmail.com', '2023-01-15 03:50:45', '$2y$10$BJJBfq3KeJWsIUlasNxziexOijN8L1VisQ1a9Akk78O69U3ta0Wp.', NULL, '2023-01-15 08:50:45', '2023-01-15 08:50:45'),
(7, 'juan', 'leimeandresh@gmail.com', '2023-01-15 04:09:27', '$2y$10$RpdYDGV3Usm2.m7VkxOfueXJPa6MSB4ei2q26bCbpr0jfQlSALMfm', NULL, '2023-01-15 09:09:27', '2023-01-15 09:09:27');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id_category`);

--
-- Indices de la tabla `category_product`
--
ALTER TABLE `category_product`
  ADD KEY `category_id` (`category_id`,`product_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indices de la tabla `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id_product`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `category`
--
ALTER TABLE `category`
  MODIFY `id_category` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `products`
--
ALTER TABLE `products`
  MODIFY `id_product` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `category_product`
--
ALTER TABLE `category_product`
  ADD CONSTRAINT `category_product_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id_product`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `category_product_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `category` (`id_category`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
